echo "Lancement du serveur... (1Go de ram par défaut) | Travertine-153"
java -Xms128m -Xmx1g -jar Travertine-153.jar nogui
