echo "Lancement du serveur... (2Go de ram par défaut) | Spigot 1.11"
java -Xms128m -Xmx2g -jar Spigot-1.11.jar nogui
