echo "Lancement du serveur... (2Go de ram par défaut) | Spigot 1.9"
java -Xms128m -Xmx2g -jar Spigot-1.9.jar nogui
